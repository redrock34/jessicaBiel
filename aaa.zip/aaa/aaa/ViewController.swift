

import UIKit



import UIKit
import CoreData

class ViewController: UIViewController,UITextFieldDelegate {
    @IBOutlet var labelName : UILabel!
    @IBOutlet var enterT : UITextField!
    
    
    // MARK: Variables declearations
    let appDelegate = UIApplication.shared.delegate as! AppDelegate //Singlton instance
    var context:NSManagedObjectContext!
    
    // MARK: View Controller life cycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        
        openDatabse()
    }
    
    // MARK: Methods to Open, Store and Fetch data
    func openDatabse()
    {
        context = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Users", in: context)
        let newUser = NSManagedObject(entity: entity!, insertInto: context)
        let newUser2 = NSManagedObject(entity: entity!, insertInto: context)
        let newUser3 = NSManagedObject(entity: entity!, insertInto: context)
        saveData(UserDBObj: newUser, UserDBObj2: newUser2, UserDBObj3: newUser3)
        
    }
    
    func saveData(UserDBObj:NSManagedObject,UserDBObj2:NSManagedObject,UserDBObj3:NSManagedObject)
    {
        UserDBObj.setValue("kim kardashian", forKey: "username")
        UserDBObj2.setValue("jessica biel", forKey: "username")
        UserDBObj3.setValue("Hailey Rienhart", forKey: "username")
        
        
        
        
        print("Storing Data..")
        do {
            try context.save()
        } catch {
            print("Storing data Failed")
        }
        
        fetchData()
    }
    
    func fetchData()
    {
        print("Fetching Data..")
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Users")
        request.returnsObjectsAsFaults = false
        do {
            let result = try context.fetch(request)
            for data in result as! [NSManagedObject] {
                let userName = data.value(forKey: "username") as! String
                
                print("User Name is : "+userName)
            }
        } catch {
            print("Fetching data Failed")
        }
    }
}
